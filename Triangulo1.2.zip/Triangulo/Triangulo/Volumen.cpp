#include "StdAfx.h"
#include "Volumen.h"


Volumen::Volumen(void)
{
}

//para accesar o revisar el contenido de los atributos
int Trianguloo::Get_lado()
{
	return lado;
}
int Trianguloo::Get_altura()
{
	return altura;
}

int Trianguloo::Get_area()
{
	return area;
}

	
//para darle valor a los atributos
void Trianguloo::Set_lado(int l)
{
		lado=l;
}
void Trianguloo::Set_altura(int al)
{
		altura=al;
}
void Trianguloo::Set_area(int a)
{
		area=a;
}

//operaciones especificas
int Trianguloo::Calcular()
{
		area=(lado*altura)/2;
		return area;
}