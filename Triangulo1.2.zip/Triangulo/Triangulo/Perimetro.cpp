#include "StdAfx.h"
#include "Perimetro.h"

Perimetro::Perimetro(void)
{
}

//para accesar o revisar el contenido de los atributos
int Perimetro::Get_lado()
{
	return lado;
}
int Perimetro::Get_s_lado()
{
	return s_lado;
}
int Perimetro::Get_perimetro()
{
	return perimetro;
}

	
//para darle valor a los atributos
void Perimetro::Set_lado(int l)
{
		lado=l;
}
void Perimetro::Set_s_lado(int sa)
{
		s_lado=sa;
}
void Perimetro::Set_perimetro(int p)
{
		perimetro=p;
}

//operaciones especificas
int Perimetro::Calcular()
{
		perimetro=(lado+s_lado+s_lado);
		return perimetro;
}