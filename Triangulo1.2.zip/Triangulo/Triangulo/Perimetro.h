#pragma once
class Perimetro
{
private:    //atributos
	int lado;
	int s_lado;
	int perimetro;

public: //metodost
	Perimetro(void); //constuctor 
	
	//metodos de acceso
	//para accesar o revisar el contenido de los atributos
	int Get_lado();
	int Get_s_lado();
	int Get_perimetro();
	
	//para darle valor a los atributos
	void Set_lado(int l);
	void Set_s_lado(int sa);
	void Set_perimetro(int p);

	//operaciones especificas
	int Calcular();
};
