#pragma once
class Volumen
{
private:    //atributos

	int altura;
	int area; //analisis

public: //metodost
	Volumen(void); //constuctor 
	
	//metodos de acceso
	//para accesar o revisar el contenido de los atributos

	int Get_altura();
	int Get_area();
	
	//para darle valor a los atributos

	void Set_altura(int al);
	void Set_area(int a);

	//operaciones especificas
	int Calcular();
};
