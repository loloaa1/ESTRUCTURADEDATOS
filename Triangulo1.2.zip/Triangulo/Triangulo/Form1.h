#pragma once
#include "Trianguloo.h"
#include "Perimetro.h"
#include <iostream>
#include "msclr\marshal_cppstd.h"

namespace Triangulo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnCalcular;
	protected: 

	protected: 

	protected: 
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtLado;
	private: System::Windows::Forms::TextBox^  txtArea;


	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtAltura;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtPerimetro;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  txts_lado;






	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtLado = (gcnew System::Windows::Forms::TextBox());
			this->txtArea = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtAltura = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtPerimetro = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txts_lado = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(91, 218);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 0;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(51, 24);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(40, 17);
			this->label1->TabIndex = 1;
			this->label1->Text = L"Lado";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(51, 87);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(45, 17);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Altura";
			// 
			// txtLado
			// 
			this->txtLado->Location = System::Drawing::Point(133, 24);
			this->txtLado->Name = L"txtLado";
			this->txtLado->Size = System::Drawing::Size(100, 22);
			this->txtLado->TabIndex = 3;
			// 
			// txtArea
			// 
			this->txtArea->Location = System::Drawing::Point(133, 132);
			this->txtArea->Name = L"txtArea";
			this->txtArea->Size = System::Drawing::Size(100, 22);
			this->txtArea->TabIndex = 4;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(54, 136);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(38, 17);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Area";
			// 
			// txtAltura
			// 
			this->txtAltura->Location = System::Drawing::Point(133, 87);
			this->txtAltura->Name = L"txtAltura";
			this->txtAltura->Size = System::Drawing::Size(100, 22);
			this->txtAltura->TabIndex = 6;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(57, 175);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(69, 17);
			this->label4->TabIndex = 7;
			this->label4->Text = L"Perimetro";
			// 
			// txtPerimetro
			// 
			this->txtPerimetro->Location = System::Drawing::Point(133, 175);
			this->txtPerimetro->Name = L"txtPerimetro";
			this->txtPerimetro->Size = System::Drawing::Size(100, 22);
			this->txtPerimetro->TabIndex = 8;
			this->txtPerimetro->TextChanged += gcnew System::EventHandler(this, &Form1::txtPerimetro_TextChanged);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(54, 57);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(53, 17);
			this->label5->TabIndex = 9;
			this->label5->Text = L"S Lado";
			// 
			// txts_lado
			// 
			this->txts_lado->Location = System::Drawing::Point(133, 57);
			this->txts_lado->Name = L"txts_lado";
			this->txts_lado->Size = System::Drawing::Size(100, 22);
			this->txts_lado->TabIndex = 10;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->txts_lado);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->txtPerimetro);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtAltura);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtArea);
			this->Controls->Add(this->txtLado);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnCalcular);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 
		 Trianguloo triangulo; //Creando el objeto cuadradito
		 triangulo.Set_lado(System::Convert::ToInt32(txtLado->Text)); triangulo.Set_altura(System::Convert::ToInt32(txtAltura->Text));
		 int areafin;
		 areafin=triangulo.Calcular();
		 txtArea->Text=System::Convert::ToString(areafin); 
		 
		 
			 }
private: System::Void txtPerimetro_TextChanged(System::Object^  sender, System::EventArgs^  e) {

			 Perimetro perimetro; //Creando el objeto cuadradito
		 perimetro.Set_lado(System::Convert::ToInt32(txtLado->Text)); perimetro.Set_s_lado(System::Convert::ToInt32(txts_lado->Text));
		 int perimetrofin;
		 perimetrofin=perimetro.Calcular();
		 txtPerimetro->Text=System::Convert::ToString(perimetrofin);
		 }
};
}

