#pragma once
#include "Persona.h"
class Compradores:public Persona
{
	Compradores(void);
};