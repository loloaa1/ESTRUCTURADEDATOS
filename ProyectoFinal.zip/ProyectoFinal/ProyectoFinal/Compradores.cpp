#include "StdAfx.h"
#include "Compradores.h"


Compradores::Compradores(void)
{
}
