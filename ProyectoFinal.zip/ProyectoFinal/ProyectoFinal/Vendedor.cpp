#include "StdAfx.h"
#include "Vendedor.h"

