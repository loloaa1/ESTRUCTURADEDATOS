#pragma once
#include "Producto.h"
class Lista_Productos
{
public:
	int n;
	Lista_Productos(void);
	void Insertar(Producto *&lista,string name_p,string cat, int price, int cant);
	void Mostrar(Producto *&lista, DataGridView^ grilla);
	void Eliminar(Producto *&);
	int getn();
};

