#pragma once
#include <string>
#include <iostream>
#include <stdlib.h>

using namespace std;

class Persona
{
public:
	string nombre;
	int edad;
	int numero_registro;
	int numero_cuenta;
	int numero_contacto;
	string email;

	Persona(void);
	void set_nombre(string name);
	string get_nombre();
	void set_edad(int age);
	int get_edad();
	void set_numero_registro(int reg);
	int get_numero_registro();
	void set_numero_cuenta(int acc);
	int get_numero_cuenta();
	void set_numero_contacto(int cont);
	int get_nunero_contacto();
	void set_email(string ema);
	string get_email();
};
