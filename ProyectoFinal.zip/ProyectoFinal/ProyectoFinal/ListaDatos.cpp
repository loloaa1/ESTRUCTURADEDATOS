#include "StdAfx.h"
#include "ListaDatos.h"

/*
ListaDatos::ListaDatos(void)
{

}
ListaDatos::ListaDatos(string nom, string cat, int pr, int cant, int cod) {
		nombre_P = nom;
		categoria = cat;
		precio = pr;
		cantidad = cant;
		codigo = cod; 
	}

void ListaDatos::setDatos(string nom, string cat, int pr, int cant, int cod) {
		nombre_P = nom;
		categoria = cat;
		precio = pr;
		cantidad = cant;
		codigo = cod; 
}
string ListaDatos::getNombre(){
	return nombre_P;
}
string ListaDatos::getCategoria(){
	return categoria;
}
int ListaDatos::getPrecio(){
	return precio;
}
int ListaDatos::getCantidad(){
	return cantidad;
}
int ListaDatos::getCodigo(){
	return codigo;
}

void ListaDatos::guardarArchivo(ofstream &fsalida) {
	//abrir el archivo
		fsalida.write(reinterpret_cast<char *>(&nombre_P), sizeof(nombre_P));
		fsalida.write(reinterpret_cast<char *>(&categoria), sizeof(categoria));
		fsalida.write(reinterpret_cast<char *>(&precio), sizeof(precio));
		fsalida.write(reinterpret_cast<char *>(&cantidad), sizeof(cantidad));
		fsalida.write(reinterpret_cast<char *>(&codigo), sizeof(codigo));
		//cerrar el archivo
}

bool ListaDatos::leerArchivo(ifstream &fentrada) {
		bool k = false;
		if (fentrada.is_open() == true) {
			fentrada.read(reinterpret_cast<char *>(&nombre_P), sizeof(nombre_P));
			if (fentrada.eof() == false) {				
				fentrada.read(reinterpret_cast<char *>(&categoria), sizeof(categoria));
				fentrada.read(reinterpret_cast<char *>(&precio), sizeof(precio));
				fentrada.read(reinterpret_cast<char *>(&cantidad), sizeof(cantidad));
				fentrada.read(reinterpret_cast<char *>(&codigo), sizeof(codigo));
				k = true;
			}else {
				//cout << endl << "Registro no existe";
			}
		}else {
			//cout << endl << "Arhivo no existe";
		}
		return(k);
}

bool ListaDatos::eliminar(fstream &fes, int cod){
		bool k = false;
		if (fes.is_open() == true) {
			fes.seekg(getTamBytesRegistro() * (cod - 1), ios::beg);
			fes.read(reinterpret_cast<char *>(&nombre_P), sizeof(nombre_P));
			if (fes.eof() == false) {
				fes.read(reinterpret_cast<char *>(&categoria), sizeof(categoria));
				fes.read(reinterpret_cast<char *>(&precio), sizeof(precio));
				fes.read(reinterpret_cast<char *>(&cantidad), sizeof(cantidad));
				fes.read(reinterpret_cast<char *>(&codigo), sizeof(codigo));
		
				codigo = -1;
				fes.seekp(getTamBytesRegistro() * (cod - 1), ios::beg);
				fes.write(reinterpret_cast<char *>(&nombre_P), sizeof(nombre_P));
				fes.write(reinterpret_cast<char *>(&categoria), sizeof(categoria));
				fes.write(reinterpret_cast<char *>(&precio), sizeof(precio));
				fes.write(reinterpret_cast<char *>(&cantidad), sizeof(cantidad));
				fes.write(reinterpret_cast<char *>(&codigo), sizeof(codigo));
				k = true;
			}else {
				//cout << endl << "Registro no existe";
			}			
		}else {
			//cout << endl << "Arhivo no existe";
		}
		return(k);
}


bool ListaDatos::modificar(fstream &fes, int cod){
		bool k = false;
		if (fes.is_open() == true) {
			string nomAux;
			nomAux=nombre_P;
			fes.seekg(getTamBytesRegistro() * (cod - 1), ios::beg);
			fes.read(reinterpret_cast<char *>(&nombre_P), sizeof(nombre_P));
			if (fes.eof() == false) {
				nombre_P=nomAux;
				//estado = 'A';
				fes.seekp(getTamBytesRegistro() * (cod - 1), ios::beg);
				fes.write(reinterpret_cast<char *>(&nombre_P), sizeof(nombre_P));
				fes.write(reinterpret_cast<char *>(&categoria), sizeof(categoria));
				fes.write(reinterpret_cast<char *>(&precio), sizeof(precio));
				fes.write(reinterpret_cast<char *>(&cantidad), sizeof(cantidad));
				fes.write(reinterpret_cast<char *>(&codigo), sizeof(codigo));
				k = true;
			}else {
				//cout << endl << "Registro no existe";
			}			
		}else {
			//cout << endl << "Arhivo no existe";
		}
		return(k);
}

bool ListaDatos::buscar(ifstream &fentrada, int cod) {
		bool k = false;
		if (fentrada.is_open() == true) {
			fentrada.seekg(getTamBytesRegistro() * (cod - 1), ios::beg);
			fentrada.read(reinterpret_cast<char *>(&nombre_P), sizeof(nombre_P));
			fentrada.read(reinterpret_cast<char *>(&categoria), sizeof(categoria));
			fentrada.read(reinterpret_cast<char *>(&precio), sizeof(precio));
			fentrada.read(reinterpret_cast<char *>(&cantidad), sizeof(cantidad));
			fentrada.read(reinterpret_cast<char *>(&codigo), sizeof(codigo));
			if (fentrada.eof() == false) {
				k = true;
			}
			else {
				//cout << endl << "Registro no XX existe";
			}
		}
		else {
			//cout << endl << "Arhivo no existe";
		}
		return(k);
}

int ListaDatos::getTamBytesRegistro() {
		return(sizeof(nombre_P) + sizeof(categoria) + sizeof(precio) + sizeof(cantidad) + sizeof(codigo) );
}

*/

ListaDatos::ListaDatos(void) {

}
void ListaDatos::cargar(string nom, string cat, int pr, int cant, int cod) {
	ofstream archivo;
	string s;
	archivo.open("C:\\Users\\WINDOWS\\Desktop\\ProyectoFinal\\ProyectoFinal\\texto1.txt", ios::out);
	if (archivo.fail()) {
		/*grilla->ColumnCount = 1;
		grilla->RowCount = 1;
		s = "error";
		grilla->Rows[0]->Cells[0]->Value = System::Convert::ToString(s);*/
	}
	else {
		archivo << cod << endl;
		archivo << nom << endl;
		archivo << pr << endl;
		archivo << cant << endl;
		archivo << cod << endl;
		archivo.close();
	}
}
void ListaDatos::listar(DataGridView^ grilla) {
	ifstream archivo;
	archivo.open("C:\\Users\\WINDOWS\\Desktop\\ProyectoFinal\\ProyectoFinal\\texto1.txt", ios::in);
	int c = 0, r = 0;
	string dato;
	if (archivo.fail()) {
		/*grilla->ColumnCount = 1;
		grilla->RowCount = 1;
		dato = "error";
		grilla->Rows[0]->Cells[0]->Value = System::Convert::ToString(dato);*/
	}
	else {
		grilla->ColumnCount = 5;
		grilla->RowCount = contar(grilla);
		while (!archivo.eof()) {
			while (c < 5) {
				getline(archivo, dato);
				grilla->Rows[r]->Cells[c]->Value = System::Convert::ToString(dato);
				c++;
			}
			c = 0;
			r++;
		}
		archivo.close();
	}

}
int ListaDatos::contar(DataGridView^ grilla){
	ifstream archivo;
	archivo.open("C:\\Users\\WINDOWS\\Desktop\\ProyectoFinal\\ProyectoFinal\\texto1.txt", ios::in);
	int r = 0,c = 0;
	string dato;
	if (archivo.fail()) {
		/*grilla->ColumnCount = 1;
		grilla->RowCount = 1;
		dato= "error";
		grilla->Rows[0]->Cells[0]->Value = System::Convert::ToString(dato);*/
		return 0;
	}
	else {
		while (!archivo.eof()) {
			while (c < 5) {
				getline(archivo, dato);
				c++;
			}
			c = 0;
			r++;
		}
		return r;
		archivo.close();
	}
}