#include "StdAfx.h"
#include "MetodosDatos.h"

/*
MetodosDatos::MetodosDatos(string nomArch)
{
	nomArchivo=nomArch;
}
void MetodosDatos::introducirDatos(ListaDatos *newReg, string nom,string cat, int pr, int cant, int cod) {
		fflush( stdin );
		newReg->setDatos(nom,cat,pr,cant,cod);		
}


void MetodosDatos::mostrarRegistro(int cod,DataGridView^ grilla){
		
		grilla->Rows[0]->Cells[0]->Value = System::Convert::ToString(List->getCodigo());
		grilla->Rows[0]->Cells[1]->Value = marshal_as<System::String^>(List->getNombre());
		grilla->Rows[0]->Cells[2]->Value = System::Convert::ToString(List->getCantidad());
		grilla->Rows[0]->Cells[3]->Value = System::Convert::ToString(List->getPrecio());
		grilla->Rows[0]->Cells[4]->Value = marshal_as<System::String^>(List->getCategoria());
}
void MetodosDatos::adicionarNuevo(string nom,string cat, int pr, int cant, int cod) {
		ofstream fsalida(nomArchivo, ios::app | ios::binary);	
		List = new ListaDatos();
		introducirDatos(List,nom,cat,pr,cant,cod);
		List->guardarArchivo(fsalida);	
		fsalida.close();
}

void MetodosDatos::listar(DataGridView^ grilla) {
		int cr = 0;
		//cout << endl<<endl << "Los registros son --->>> : " << endl;
		List = new ListaDatos();
		ifstream fentrada(nomArchivo, ios::in | ios::binary);
		while (List->leerArchivo(fentrada) == true) {
			cr++;
			if (List->getCodigo() > 0) {
				mostrarRegistro(cr,grilla);
			}
		}
		fentrada.close();
}
/*
int buscarReg() {
		int nroReg;
		cout << endl<<endl<< "Introducir numero de registro a buscar :  ";
		cin >> nroReg;
		amig = new Amigo();
		ifstream fentrada(nomArchivo, ios::in | ios::binary);
		if(amig->buscar(fentrada,nroReg) == true) {
			mostrarRegistro(nroReg);			
		} else {
			cout << endl << "Registro no existe";
			nroReg=-1;
		}
		fentrada.close();
		return(nroReg);
}
	
void eliminarReg() {
		int nroReg;
		nroReg = buscarReg();
		if(nroReg > 0){
			fstream fes(nomArchivo, ios::in | ios::out | ios::binary);
			amig = new Amigo();
			if (amig->eliminar(fes, nroReg) == true) {
				cout << endl << "Registro eliminado correctmente "<<endl;
			} else {
				cout << endl << "Registro no existe pa eliminar"<<endl;
			}
			fes.close();
		}
}

void modificarReg() {
		int nroReg;
		nroReg = buscarReg();
		if(nroReg>0){
			fstream fes(nomArchivo, ios::in | ios::out | ios::binary);
			amig = new Amigo();
			introducirDatos(amig);
			if (amig->modificar(fes, nroReg) == true) {
				cout << endl << "modificado correctamente... "<< endl ;
			} else {
				cout << endl << "Registro no existe pa modificar";
			}
			fes.close();
		}
		
}
*/