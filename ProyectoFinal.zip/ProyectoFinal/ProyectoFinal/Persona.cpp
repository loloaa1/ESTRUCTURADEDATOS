#include "StdAfx.h"
#include "Persona.h"

Persona::Persona(void)
{
}
void Persona::set_nombre(string name) {
	nombre = name;
}
string Persona::get_nombre() {
	return nombre;
}
void Persona::set_edad(int age) {
	edad = age;
}
int Persona::get_edad() {
	return edad;
}
void Persona::set_numero_registro(int reg) {
	numero_registro = reg;
}
int Persona::get_numero_registro() {
	return numero_registro;
}
void Persona::set_numero_cuenta(int acc) {
	numero_cuenta = acc;
}
int Persona::get_numero_cuenta() {
	return numero_cuenta;
}
void Persona::set_numero_contacto(int cont) {
	numero_contacto = cont;
}
int Persona::get_nunero_contacto() {
	return numero_contacto;
}
void Persona::set_email(string ema) {
	email = ema;
}
string Persona::get_email() {
	return email;
}