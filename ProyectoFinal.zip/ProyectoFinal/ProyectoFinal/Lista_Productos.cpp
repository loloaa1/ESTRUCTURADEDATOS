#include "StdAfx.h"
#include "Lista_Productos.h"


Lista_Productos::Lista_Productos(void)
{
	n=0;
}
void Lista_Productos::Insertar(Producto *&lista, string name_p, string cat, int price, int cant) {
	Producto* nuevo_Producto = new Producto();
	nuevo_Producto->nombre_P = name_p;
	nuevo_Producto->categoria = cat;
	nuevo_Producto->precio = price;
	nuevo_Producto->cantidad = cant;
	nuevo_Producto->codigo = n+1;
	Producto* aux1 = lista;
	Producto* aux2;
	while ((aux1 != NULL) && (aux1->codigo < n+1)) {
		aux2 = aux1;
		aux1 = aux1->siguiente;
	}
	if (lista == aux1) {
		lista = nuevo_Producto;
	}
	else {
		aux2->siguiente = aux1;
	}
	nuevo_Producto->siguiente = aux1;
	n++;
}
void Lista_Productos::Mostrar(Producto *&lista, DataGridView^ grilla) {
	int i=0;
	Producto* actual = new Producto;
	actual = lista;
	grilla->ColumnCount = 5;
	grilla->RowCount = n;
	while (actual != NULL)
	{
		grilla->Rows[i]->Cells[0]->Value = System::Convert::ToString(actual->codigo);
		grilla->Rows[i]->Cells[1]->Value = marshal_as<System::String^>(actual->nombre_P);
		grilla->Rows[i]->Cells[2]->Value = System::Convert::ToString(actual->cantidad);
		grilla->Rows[i]->Cells[3]->Value = System::Convert::ToString(actual->precio);
		grilla->Rows[i]->Cells[4]->Value = marshal_as<System::String^>(actual->categoria);
		actual = actual->siguiente;
	}
}
void Lista_Productos::Eliminar(Producto*&) {

}
int Lista_Productos::getn(){
	return n;
}
